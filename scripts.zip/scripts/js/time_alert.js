$(document).ready(function() {
    setTimeout(function(){ 
        $(".alert").hide(); }, 3000);
    
});