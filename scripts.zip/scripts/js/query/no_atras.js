window.history.forward();
function sinVueltaAtras(){ window.history.forward(); }