<?php


    //$conexion = new mysqli("localhost","root","1234");
    $conexion = new mysqli("localhost","root","");
    //$conexion = new mysqli("localhost","root","Freddy0770");
    


    //$conexion = new mysqli("localhost","root","");
    date_default_timezone_set("America/Santo_Domingo");
?>