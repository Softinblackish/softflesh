<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/login.css">

    <title>Login</title>
    
</head>
<body>
    <div id="contenedor">
    <div>
        <img id="img-fondo" src="../../img/captura.png" class="img-fluid"/>
    </div>
        <div id="recuadro_login">
        
            <div id="credenciales">
            <br>
                <Form action="../../scripts/login/login.php" method="post">
                <center>
                <img src="../../img/logo.png" alt="" class="img-fluid" style="margin-left:25px;"><br><br>
                    <div class="form-group" >
                        <input  class="form-control" type="text" placeholder="&#xe210; Empresa" name="empresa" require>
                    </div>
                    <br><br>
                    <div class="form-group" >
                        <input class="form-control" type="text" placeholder="&#xe008; Nombre de usuario" name="user">
                    </div>
                    <div class="form-group" >
                        
                        <input class="form-control" type="password" placeholder="&#xe210; Contraseña" name="pass" >
                    </div>
                </center>
                    <input type="submit" style="margin-left:105px;" value="Acceder" class="btn btn" id="enviar"/> <button style="margin-left:20px;" class="btn btn" id="enviar" >Cancelar</button>
                </Form>
            </div>
           


        

    
</body>
</html>